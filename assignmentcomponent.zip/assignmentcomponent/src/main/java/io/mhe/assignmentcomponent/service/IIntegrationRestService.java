package io.mhe.assignmentcomponent.service;

import org.springframework.stereotype.Service;

@Service
public interface IIntegrationRestService {

}
