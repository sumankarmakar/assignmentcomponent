package io.mhe.assignmentcomponent.vo;

public class ConnectApplicationException extends Throwable {
    public ConnectApplicationException(String s) {
    }
}
