package io.mhe.assignmentcomponent.vo;

public class Configuration {
    public static String getSystemValue(String isSslEnabled) {
        return "";
    }

    public static boolean isTomcat() {
        return true;
    }
}
